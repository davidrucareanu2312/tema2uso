#!/bin/bash

export USERNAME="david.rucareanu"

TOKEN=$(curl -m 1 -s http://141.85.232.81:5000/uso/part1/$USERNAME)

curl -m 1 -s -X POST -H "Content-Type:application/json" -d "{\"token\": \"$TOKEN\"}" http://141.85.232.81:5000/uso/part2
